function d = double(a)
d = a.x;