function c = minus(a,b)
% MINUS implements a-b, where either a or b is an adiff object.

c = plus(a,-b);

