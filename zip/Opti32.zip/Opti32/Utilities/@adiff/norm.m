function n = norm(a)
n = sqrt(sum(a.^2));