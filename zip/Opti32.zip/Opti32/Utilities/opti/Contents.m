% OPTI Toolbox
% Version 2.16 (R2014b) 25-July-2015
%  Copyright (C) 2011-2015 Jonathan Currie (I2C2)
